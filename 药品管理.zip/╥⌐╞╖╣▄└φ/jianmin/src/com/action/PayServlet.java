package com.action;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.PayBean;
import com.util.Constant;

public class PayServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public PayServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType(Constant.CONTENTTYPE);
		request.setCharacterEncoding(Constant.CHARACTERENCODING);
		PayBean pb=new PayBean();
		String method=request.getParameter("method").trim();
		////////////////////////////////////////////////////////////////////// 
		if(method.equals("addTYPE")){
			String name=request.getParameter("booktype");
			int flag=pb.addTYPE(name);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/type/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/type/index.jsp").forward(request, response);
			}
		}
		///////////////////////////////////////////////////////////////////////del
		else if(method.equals("delTYPE")){
			String id=request.getParameter("id");
			int flag=pb.delTYPE(id);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/type/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/type/index.jsp").forward(request, response);
			}
		}
/////////////////////////////////////////////////////////////////////// 
		if(method.equals("addBOOK")){
			String booktype=request.getParameter("booktype");
			String name=request.getParameter("name");
			String author=request.getParameter("author");
			String cbs=request.getParameter("cbs");
			String isbn=request.getParameter("isbn");
			String price=request.getParameter("price");
			String num=request.getParameter("num");
			String intro=request.getParameter("intro");
			String jyjg=request.getParameter("jyjg");
			int flag=pb.addBOOK(booktype, name, author, cbs, isbn, price, num, intro, jyjg);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/pro/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/pro/index.jsp").forward(request, response);
			}
		}
		///////////////////////////////////////////////////////////////////////del
		else if(method.equals("upBOOK")){
			String id=request.getParameter("id");
			String booktype=request.getParameter("booktype");
			String name=request.getParameter("name");
			String author=request.getParameter("author");
			String cbs=request.getParameter("cbs");
			String isbn=request.getParameter("isbn");
			String price=request.getParameter("price");
			String num=request.getParameter("num");
			String intro=request.getParameter("intro");
			String jyjg=request.getParameter("jyjg");
			int flag=pb.upBOOK(id, booktype, name, author, cbs, isbn, price, num, intro, jyjg);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/pro/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/pro/index.jsp").forward(request, response);
			}
		}
		else if(method.equals("delBOOK")){
			String id=request.getParameter("id");
			int flag=pb.delBOOK(id);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/pro/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/pro/index.jsp").forward(request, response);
			}
		}
///////////////////////////////////////////////////////////////////////��Ӧ��
		else if(method.equals("addMEMBER")){
			//String card,String name,String sex,String age,String address,String tel,String email,String remark
			String card=request.getParameter("card");
			String name=request.getParameter("name");
			String sex=request.getParameter("sex");
			String age=request.getParameter("age");
			String address=request.getParameter("address");
			String tel=request.getParameter("tel");
			String email=request.getParameter("email");
			String remark=request.getParameter("remark");
			int flag=pb.addMEMBER(card, name, sex, age, address, tel, email, remark);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/member/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/member/index.jsp").forward(request, response);
			}
		}
		///////////////////////////////////////////////////////////////////////del
		else if(method.equals("upMEMBER")){
			String card=request.getParameter("card");
			String name=request.getParameter("name");
			String sex=request.getParameter("sex");
			String age=request.getParameter("age");
			String address=request.getParameter("address");
			String tel=request.getParameter("tel");
			String email=request.getParameter("email");
			String remark=request.getParameter("remark");
			int flag=pb.upMEMBER(card, name, sex, age, address, tel, email, remark);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/member/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/member/index.jsp").forward(request, response);
			}
		}
		else if(method.equals("delMEMBER")){
			String id=request.getParameter("id");
			int flag=pb.delMEMBER(id);
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/member/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/member/index.jsp").forward(request, response);
			}
		}
 
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
