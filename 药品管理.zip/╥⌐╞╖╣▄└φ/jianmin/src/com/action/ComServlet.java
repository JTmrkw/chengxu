package com.action;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.ComBean;
import com.util.Constant;

public class ComServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public ComServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType(Constant.CONTENTTYPE);
		request.setCharacterEncoding(Constant.CHARACTERENCODING);
		HttpSession session = request.getSession();
		ComBean cBean = new ComBean();
		String date2=new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
		String method = request.getParameter("method");
		if(method.equals("addRk")){  //add  
			 String pid = request.getParameter("pid");
			 String sl = request.getParameter("sl");
			 String jg = request.getParameter("jg");
			 String bz = request.getParameter("bz");
			 String sql="insert into rk(pid, sl, jg,bz,sj) values('"+pid+"', '"+sl+"', '"+jg+"',	'"+bz+"', '"+date2+"' )";
			// System.out.println(sql);
				 int flag = cBean.comUp(sql);
					if(flag == Constant.SUCCESS){ 
						request.setAttribute("message", "�����ɹ���");
						request.getRequestDispatcher("admin/rk/index.jsp").forward(request, response); 
					}
					else { 
						request.setAttribute("message", "����ʧ�ܣ�");
						request.getRequestDispatcher("admin/rk/index.jsp").forward(request, response); 
					}
			
		}
		else if(method.equals("upRk")){ ///update  
			String id = request.getParameter("id");
			String pid = request.getParameter("pid");
			 String sl = request.getParameter("sl");
			 String jg = request.getParameter("jg");
			 String bz = request.getParameter("bz");
			int flag = cBean.comUp("update rk set pid='"+pid+"', sl='"+sl+"', jg='"+jg+"',	bz='"+bz+"' where id='"+id+"'");
			if(flag == Constant.SUCCESS){ 
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/rk/index.jsp").forward(request, response); 
			}
			else if(flag == Constant.NAME_ERROR){ 
				request.setAttribute("message", "����ʧ�ܣ�");
				request.getRequestDispatcher("admin/rk/index.jsp").forward(request, response); 
			}
		}
		else if(method.equals("delRk")){  //del t 
			String id = request.getParameter("id");
			int flag = cBean.comUp("delete from rk where id='"+id+"'");
			if(flag == Constant.SUCCESS){ 
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/rk/index.jsp").forward(request, response); 
			}
			else { 
				request.setAttribute("message", "����ʧ�ܣ�");
				request.getRequestDispatcher("admin/rk/index.jsp").forward(request, response); 
			}
		}
		
		//////////////////////////////////////////////////////////////////////////////////////����˻�
		else if(method.equals("addRkTh")){  //add  
			 String rid = request.getParameter("rid");
			 String sl = request.getParameter("sl"); 
			 String bz = request.getParameter("bz");
			 
			 int rksl=cBean.getInt("select sum(sl) from rk where  id='"+rid+"'");//����Ʒ�������
			 int prosl=cBean.getInt("select pro.num from pro,rk where rk.pid=pro.id and rk.id='"+rid+"'");//������Ʒʱ������
			 int thsl=cBean.getInt("select sum(sl) from rkth where rid='"+rid+"'");//�Ѿ��˻�����
			 int xssl=0;//��ȥ�Ѿ����۵�����
			 int xsthsl=0;//���������˻�������  ������Ʒ����+�������+�����˻�����-����������-�Ѿ��˻�����
			 
			 String pid=cBean.getString("select pid from rk where id='"+rid+"'");
			 xssl=cBean.getInt("select sum(sl) from xs where pid='"+pid+"'");
			 xsthsl=cBean.getInt("select sum(xsth.sl) from xs,xsth where xs.id=xsth.xid and xs.pid='"+pid+"' ");
			 
			 if((rksl+prosl+xsthsl-xssl-thsl)>Integer.parseInt(sl)){
				 String sql="insert into rkth(rid, sl,bz,sj) values('"+rid+"', '"+sl+"','"+bz+"', '"+date2+"' )";
				 int flag = cBean.comUp(sql);
					if(flag == Constant.SUCCESS){ 
						request.setAttribute("message", "�����ɹ���");
						request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
					}
					else { 
						request.setAttribute("message", "����ʧ�ܣ�");
						request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
					}
			 }else{
				 request.setAttribute("message", "�˻��������ڿ�棬��������");
				 request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
			 }
			
		}
		else if(method.equals("upRkTh")){ ///update  
			String id = request.getParameter("id");
			 String rid = request.getParameter("rid");
			 String sl = request.getParameter("sl"); 
			 String bz = request.getParameter("bz");
			 
			 int rksl=cBean.getInt("select sum(sl) from rk where  id='"+rid+"'");//����Ʒ�������
			 int prosl=cBean.getInt("select pro.num from pro,rk where rk.pid=pro.id and rk.id='"+rid+"'");//������Ʒʱ������
			 int thsl=cBean.getInt("select sum(sl) from rkth where rid='"+rid+"' and id!='"+id+"'");//�Ѿ��˻�����
			 int xssl=0;//��ȥ�Ѿ����۵�����
			 int xsthsl=0;//���������˻�������  ������Ʒ����+�������+�����˻�����-����������-�Ѿ��˻�����
			 
			 String pid=cBean.getString("select pid from rk where id='"+rid+"'");
			 xssl=cBean.getInt("select sum(sl) from xs where pid='"+pid+"'");
			 xsthsl=cBean.getInt("select sum(xsth.sl) from xs,xsth where xs.id=xsth.xid and xs.pid='"+pid+"' ");
			 
			 if((rksl+prosl+xsthsl-xssl-thsl)>Integer.parseInt(sl)){
				 String sql="update rkth set rid='"+rid+"', sl='"+sl+"',bz='"+bz+"' where id= '"+id+"' ";
				 int flag = cBean.comUp(sql);
					if(flag == Constant.SUCCESS){ 
						request.setAttribute("message", "�����ɹ���");
						request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
					}
					else { 
						request.setAttribute("message", "����ʧ�ܣ�");
						request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
					}
			 }else{
				 request.setAttribute("message", "�˻��������ڿ�棬��������");
				 request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
			 }
			
		}
		else if(method.equals("delRkTh")){  //del 
			String id = request.getParameter("id");
			int flag = cBean.comUp("delete from rkth where id='"+id+"'");
			if(flag == Constant.SUCCESS){ 
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
			}
			else { 
				request.setAttribute("message", "����ʧ�ܣ�");
				request.getRequestDispatcher("admin/rk/rkth.jsp").forward(request, response); 
			}
		}
		
		
		
		/////////////////////////////////////////////////////////////////////////////////////////////����
		else if(method.equals("addXs")){  //add  
			 String pid = request.getParameter("pid");
			 String sl = request.getParameter("sl");
			 String jg = request.getParameter("jg");
			 String bz = request.getParameter("bz");
			 
			 int prosl=cBean.getInt("select num from pro where id='"+pid+"'");//������Ʒʱ������
			 int rksl=cBean.getInt("select sum(sl) from rk where  pid='"+pid+"'");//����Ʒ�������
			 int rkth=cBean.getInt("select sum(rkth.sl) from rkth,rk where rkth.rid=rk.id and rk.pid='"+pid+"'");
			 int xs=cBean.getInt("select sum(sl) from xs where pid='"+pid+"'");
			 int xsth=cBean.getInt("select sum(xsth.sl) from xsth,xs where xsth.xid=xs.id and xs.pid='"+pid+"'");
			 if((prosl+rksl-rkth-xs+xsth)>=Integer.parseInt(sl)){
				 String sql="insert into xs(pid, sl, jg,bz,sj) values('"+pid+"', '"+sl+"', '"+jg+"',	'"+bz+"', '"+date2+"' )";
				int flag = cBean.comUp(sql);
				if(flag == Constant.SUCCESS){ 
					request.setAttribute("message", "�����ɹ���");
					request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
				}
				else { 
					request.setAttribute("message", "����ʧ�ܣ�");
					request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
				}
			 }
			 else{
				 request.setAttribute("message", "��治�㣡");
				request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
			 }
			
		}
		else if(method.equals("upXs")){ ///update  
			String id = request.getParameter("id");
			String pid = request.getParameter("pid");
			 String sl = request.getParameter("sl");
			 String jg = request.getParameter("jg");
			 String bz = request.getParameter("bz");
			 
			 int prosl=cBean.getInt("select num from pro where id='"+pid+"'");//������Ʒʱ������
			 int rksl=cBean.getInt("select sum(sl) from rk where  pid='"+pid+"'");//����Ʒ�������
			 int rkth=cBean.getInt("select sum(rkth.sl) from rkth,rk where rkth.rid=rk.id and rk.pid='"+pid+"'");
			 int xs=cBean.getInt("select sum(sl) from xs where pid='"+pid+"' and id!='"+id+"'");
			 int xsth=cBean.getInt("select sum(xsth.sl) from xsth,xs where xsth.xid=xs.id and xs.pid='"+pid+"'");
			 if((prosl+rksl-rkth-xs+xsth)>=Integer.parseInt(sl)){
				 String sql="update xs set pid='"+pid+"', sl='"+sl+"', jg='"+jg+"',	bz='"+bz+"' where id= '"+id+"' ";
				int flag = cBean.comUp(sql);
				if(flag == Constant.SUCCESS){ 
					request.setAttribute("message", "�����ɹ���");
					request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
				}
				else { 
					request.setAttribute("message", "����ʧ�ܣ�");
					request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
				}
			 }
			 else{
				 request.setAttribute("message", "��治�㣡");
				request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
			 }
		}
		else if(method.equals("delXs")){  //del  
			String id = request.getParameter("id");
			int flag = cBean.comUp("delete from xs where id='"+id+"'");
			if(flag == Constant.SUCCESS){ 
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
			}
			else { 
				request.setAttribute("message", "����ʧ�ܣ�");
				request.getRequestDispatcher("admin/xs/index.jsp").forward(request, response); 
			}
		}
		///                                                                                �����˻�
		else if(method.equals("addXsTh")){  //add  
			 String xid = request.getParameter("xid");
			 String sl = request.getParameter("sl"); 
			 String bz = request.getParameter("bz");
			 //�����˻�<=�����������-�Ѿ��˻���������
			 int xssl=cBean.getInt("select sum(sl) from xs where  id='"+xid+"'");//����Ʒ���������
			 int thsl=cBean.getInt("select sum(sl) from xsth where xid='"+xid+"'");//�Ѿ��˻�����
			 if((xssl-thsl)>=Integer.parseInt(sl)){
				 String sql="insert into xsth(xid, sl,bz,sj) values('"+xid+"', '"+sl+"','"+bz+"', '"+date2+"' )";
				 int flag = cBean.comUp(sql);
					if(flag == Constant.SUCCESS){ 
						request.setAttribute("message", "�����ɹ���");
						request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
					}
					else { 
						request.setAttribute("message", "����ʧ�ܣ�");
						request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
					}
			 }else{
				 request.setAttribute("message", "�˻��������ڹ�����������������");
				 request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
			 }
			
		}
		else if(method.equals("upXsTh")){  //add 
			String id = request.getParameter("id");
			 String xid = request.getParameter("xid");
			 String sl = request.getParameter("sl"); 
			 String bz = request.getParameter("bz");
			 //�����˻�<=�����������-�Ѿ��˻���������
			 int xssl=cBean.getInt("select sum(sl) from xs where  id='"+xid+"'");//����Ʒ���������
			 int thsl=cBean.getInt("select sum(sl) from xsth where xid='"+xid+"' and id!='"+id+"'");//�Ѿ��˻�����
			 if((xssl-thsl)>=Integer.parseInt(sl)){
				 String sql="update xsth set xid='"+xid+"', sl='"+sl+"',bz='"+bz+"' where id='"+id+"'";
				 int flag = cBean.comUp(sql);
					if(flag == Constant.SUCCESS){ 
						request.setAttribute("message", "�����ɹ���");
						request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
					}
					else { 
						request.setAttribute("message", "����ʧ�ܣ�");
						request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
					}
			 }else{
				 request.setAttribute("message", "�˻��������ڹ�����������������");
				 request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
			 }
			
		}
		else if(method.equals("delXsTh")){  //add 
			 String id = request.getParameter("id");  
				 String sql="delete from xsth where id='"+id+"'";
				 int flag = cBean.comUp(sql);
					if(flag == Constant.SUCCESS){ 
						request.setAttribute("message", "�����ɹ���");
						request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
					}
					else { 
						request.setAttribute("message", "����ʧ�ܣ�");
						request.getRequestDispatcher("admin/xs/xsth.jsp").forward(request, response); 
					}
			 
		}
		else if(method.equals("cXX")){
			String lx=request.getParameter("lx");
			String keyword=request.getParameter("keyword");
			String rx=request.getParameter("rx");
			if(rx.equals("rk")){
				String sql="";String sql2="";
				if(lx.equals("id")){//select rk.*,pro.name from rk,pro where rk.pid=pro.id and rk.pid='"+keyword+"' order by rk.id desc 
					sql2="select count(*) from rk,pro where rk.pid=pro.id and rk.pid='"+keyword+"' order by rk.id desc ";
				sql="select rk.*,pro.name from rk,pro where rk.pid=pro.id and rk.pid='"+keyword+"' ";
				}
				else{
					sql2="select count(*) from rk,pro where rk.pid=pro.id and rk.pid=(select id from pro where name like '%"+keyword+"%') ";
					sql="select rk.*,pro.name from rk,pro where rk.pid=pro.id and rk.pid=(select id from pro where name like '%"+keyword+"%') order by rk.id desc";
				}
				request.setAttribute("sql", sql);request.setAttribute("sql2", sql2);
				request.getRequestDispatcher("admin/s/rk.jsp").forward(request, response); 
			}
			else{//String sql="select xs.*,pro.name from xs,pro where xs.pid=pro.id order by xs.id desc ";
				String sql="";String sql2="";
				if(lx.equals("id")){
					sql2="select count(*) from xs,pro where xs.pid=pro.id and xs.pid='"+keyword+"' ";
					sql="select xs.*,pro.name from xs,pro where xs.pid=pro.id and xs.pid='"+keyword+"' order by xs.id desc ";
				}
				else{
					sql2="select count(*) from xs,pro where xs.pid=pro.id and xs.pid=(select id from pro where name like '%"+keyword+"%')";
					sql="select xs.*,pro.name from xs,pro where xs.pid=pro.id and xs.pid=(select id from pro where name like '%"+keyword+"%') order by xs.id desc";
				}
				request.setAttribute("sql", sql);request.setAttribute("sql2", sql2);
				request.getRequestDispatcher("admin/s/xs.jsp").forward(request, response); 
			}
		}
		
		
		else if(method.equals("addkh")){ 
			String name=request.getParameter("name");
			String sex=request.getParameter("sex");
			String age=request.getParameter("age");
			String address=request.getParameter("address");
			String tel=request.getParameter("tel");
			String email=request.getParameter("email");
			String remark=request.getParameter("remark");
			int flag=cBean.comUp("insert into kh(name,sex,age,address,tel,email,remark) " +
					"values( '"+name+"','"+sex+"','"+age+"','"+address+"','"+tel+"','"+email+"','"+remark+"')");
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/kh/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/kh/index.jsp").forward(request, response);
			}
		}
		///////////////////////////////////////////////////////////////////////del
		else if(method.equals("upkh")){
			String id=request.getParameter("id");
			String name=request.getParameter("name");
			String sex=request.getParameter("sex");
			String age=request.getParameter("age");
			String address=request.getParameter("address");
			String tel=request.getParameter("tel");
			String email=request.getParameter("email");
			String remark=request.getParameter("remark");
			int flag=cBean.comUp("update kh set  name='"+name+"',sex='"+sex+"',age='"+age+"'," +
					"address='"+address+"',tel='"+tel+"',email='"+email+"',remark='"+remark+"' where id='"+id+"'");
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/kh/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/kh/index.jsp").forward(request, response);
			}
		}
		else if(method.equals("delkh")){
			String id=request.getParameter("id");
			int flag=cBean.comUp("delete from kh where id='"+id+"'");
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/kh/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/kh/index.jsp").forward(request, response);
			}
		}
		
		else if(method.equals("addqy")){ 
			String mc=request.getParameter("mc");
			String sl=request.getParameter("sl");
			String bz=request.getParameter("bz"); 
			int flag=cBean.comUp("insert into qy(mc,sl,bz,sj) " +
					"values( '"+mc+"','"+sl+"','"+bz+"','"+date2+"' )");
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/qy/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/qy/index.jsp").forward(request, response);
			}
		}
		///////////////////////////////////////////////////////////////////////del
		else if(method.equals("upqy")){
			String id=request.getParameter("id");
			String mc=request.getParameter("mc");
			String sl=request.getParameter("sl");
			String bz=request.getParameter("bz"); 
			int flag=cBean.comUp("update qy set  mc='"+mc+"',sl='"+sl+"',bz='"+bz+"'  where id='"+id+"'");
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/qy/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/qy/index.jsp").forward(request, response);
			}
		}
		else if(method.equals("delqy")){
			String id=request.getParameter("id");
			int flag=cBean.comUp("delete from qy where id='"+id+"'");
			if(flag==Constant.SUCCESS){
				request.setAttribute("message", "�����ɹ���");
				request.getRequestDispatcher("admin/qy/index.jsp").forward(request, response);
			}
			else{
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("admin/qy/index.jsp").forward(request, response);
			}
		}
		
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
